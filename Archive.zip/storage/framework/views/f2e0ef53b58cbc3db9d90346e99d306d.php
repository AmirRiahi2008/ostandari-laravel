<div class="home-experience">
<h1 class="source-sr-only">درگاه الکترونیکی استانداری مازندران</h1>
<section class="home-intro" aria-label="تازه‌های استانداری">
<div class="container-body d-f6279acc73263f"><?php echo $__env->make('site.latest', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><div class="container-body-right"><?php echo $__env->make('site.slider', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div><?php echo $__env->make('site.governor', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div>
</section>
<div class="sections-container">
<section class="home-counties" aria-label="فرمانداری‌های مازندران" data-home-reveal="true"><?php echo $__env->make('site.county-map', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></section>
<section class="home-information" aria-label="مصوبات و پیوندهای مفید" data-home-reveal="true">
<div class="container-peyvand">
<div class="mz-portal-wrapper">
<div class="mz-portal-news">
<h2 class="mz-portal-title">مصوبات و اطلاعیه‌ها</h2>
<p class="mz-portal-subtitle">آخرین مصوبات و اطلاعیه‌های سازمان را مطالعه کنید.</p>
<ul class="mz-news-list" id="mzNewsList"><?php $__empty_1 = true; $__currentLoopData = array_slice([...($home['announcements'] ?? []),...($home['resolutions'] ?? [])],0,6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><li class="mz-news-item">
<div><?php echo $__env->make('icons.document', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div>
<div>
<time class="mz-news-date"><?php echo e($ui->date($item['published_at'] ?? null)); ?></time>
<p>
<a href="<?php echo e($ui->article($item,$county)); ?>"><?php echo e($item['title']); ?></a>
</p>
</div>
</li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><li class="source-empty">مطلبی در این بخش منتشر نشده است.</li><?php endif; ?></ul>
<a class="source-more" href="<?php echo e($ui->href('/regulations',$county)); ?>">مشاهدهٔ همهٔ اسناد <span aria-hidden="true">←</span>
</a>
</div>
<div class="mz-portal-links">
<h2 class="mz-portal-title">پیوندهای مفید</h2>
<p class="mz-portal-subtitle">پیوندهای مفید سازمان را اینجا مطالعه کنید.</p>
<div class="mz-links-grid"><?php ($useful=!empty($home['links'])?$home['links']:collect($ui->data('official-site')['pages'])->whereIn('id',$ui->data('official-site')['useful'])->all()); ?><?php $__currentLoopData = array_slice($useful,0,14); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><a class="mz-link-btn" href="<?php echo e($ui->href($item['url'] ?? $item['href'] ?? '/links',$county)); ?>">
<span><?php echo e($item['title']); ?></span>
<span class="home-link-arrow" aria-hidden="true">↖</span>
</a><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div>
</div>
</div>
</div>
</section>
<section class="home-managers" aria-labelledby="home-managers-title" data-home-reveal="true">
<div class="container-modiran">
<div class="home-section-heading">
<div>
<h2 id="home-managers-title">مدیران و مسئولان استان</h2>
</div>
<a href="<?php echo e($ui->href('/managers',$county)); ?>" class="home-text-link">مشاهدهٔ همه <span aria-hidden="true">←</span>
</a>
</div><?php echo $__env->make('site.home-managers', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div>
</section>
<section class="home-public-relations" aria-labelledby="home-media-title" data-home-reveal="true">
<div class="container-omomi">
<div class="stdprx-container">
<div class="stdprx-header home-section-heading">
<div>
<h2 id="home-media-title">روابط عمومی استانداری</h2>
</div>
<a href="<?php echo e($ui->href('/news',$county)); ?>" class="home-text-link">آرشیو اخبار <span aria-hidden="true">←</span>
</a>
</div>
<div class="stdprx-body">
<div class="stdprx-tv">
<a class="stdprx-screen" href="<?php echo e($ui->href('/gallery',$county)); ?>" aria-label="گالری روابط عمومی"><?php if($image=$ui->image(($home['galleries'][0]['items'][0] ?? []))): ?><img src="<?php echo e($image); ?>" alt="" loading="lazy"><?php endif; ?><div class="home-media-caption">
<span>مازندران در قاب تصویر</span>
<strong><?php echo e($home['galleries'][0]['title'] ?? 'روایت تصویری رویدادهای استان'); ?></strong>
<span class="home-media-action">مشاهدهٔ گالری ←</span>
</div>
</a>
</div>
<div class="stdprx-timeline">
<ul class="stdprx-list"><?php $__currentLoopData = array_slice(!empty($home['events'])?$home['events']:($home['news']??[]),0,6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li class="stdprx-item">
<time><?php echo e($ui->date($item['published_at'] ?? null)); ?></time>
<a href="<?php echo e($ui->article($item,$county)); ?>"><?php echo e($item['title']); ?></a>
</li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
<div class="stdprx-actions">
<a class="stdprx-btn live" href="<?php echo e($ui->href('/news',$county)); ?>">اخبار</a>
<a class="stdprx-btn archive" href="<?php echo e($ui->href('/gallery',$county)); ?>">آرشیو</a>
</div>
</div>
</div>
</div>
</div>
</section>
<section class="home-gallery" aria-labelledby="home-gallery-title" data-home-reveal="true">
<div class="container-galery">
<section class="gallery-section">
<div class="home-section-heading">
<div>
<h2 class="gallery-title" id="home-gallery-title">گالری تصاویر</h2>
</div>
<a href="<?php echo e($ui->href('/gallery',$county)); ?>" class="home-text-link">همهٔ گالری‌ها <span aria-hidden="true">←</span>
</a>
</div>
<div class="gallery-wrapper"><?php $__currentLoopData = $home['galleries'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><article class="gallery-card1">
<div class="card1-header">
<a class="card1-title" href="<?php echo e($ui->href('/gallery?id='.$item['id'],$county)); ?>"><?php echo e($item['title']); ?></a>
<a class="jahatha" href="<?php echo e($ui->href('/gallery?id='.$item['id'],$county)); ?>">↖</a>
</div>
<a class="image-box" href="<?php echo e($ui->href('/gallery?id='.$item['id'],$county)); ?>"><?php if($image=$ui->image($item['items'][0] ?? [])): ?><img src="<?php echo e($image); ?>" alt="" loading="lazy"><?php endif; ?><p class="caption">مشاهدهٔ گالری ←</p>
</a>
</article><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div>
</section>
</div>
</section>
</div>
</div><?php /**PATH /Users/amirriahi/Sadra Computer/ostandari-laravel/resources/views/site/home.blade.php ENDPATH**/ ?>