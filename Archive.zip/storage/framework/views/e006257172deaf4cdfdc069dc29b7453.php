<?php
    $portalName=$county ? 'فرمانداری شهرستان '.$county['name'] : ($settings['site.name'] ?? 'استانداری مازندران');
    $logo=$ui->image($settings['site.logo'] ?? null) ?? '/design/site/assets/image/logo.png';
    $local=fn($href)=>$county ? preg_replace('~^/'.preg_quote($county['slug'],'~').'(?=/|\?|$)~','',$href) ?: '/' : $href;
    $rootLink=fn($href)=>collect($navigation)->first(fn($item)=>$local($item['href'])===$href);
    $categories=array_values(array_filter($navigation,fn($item)=>!in_array($local($item['href']),['/','/transparency','/managers','/duties','/about','/polls'],true)));
    $utility=[['تماس با ما','/contact'],['دسترسی سریع','/quick-access'],['سامانه شفافیت','/transparency'],['شرح وظایف واحدها','/duties'],['قوانین و مقررات','/regulations'],['دسترسی آزاد به اطلاعات','/information']];
?>
<header class="header-container" data-alpine-header="true" data-county-header="<?php echo e($county['slug'] ?? ''); ?>" x-data="portalHeader" @keydown.escape.window="dismiss()" @click.outside="mega=false;language=false">
    <a class="source-skip" href="#main-content">رفتن به محتوای صفحه</a>
    <div class="nav-bala">
        <nav class="nav-bala-right" aria-label="پیوندهای بالای سایت"><?php $__currentLoopData = $utility; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$label,$href]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><a href="<?php echo e($ui->href($href,$county)); ?>"><?php echo e($label); ?></a><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></nav>
        <div class="nav-bala-left">
            <a class="header-install-app" href="<?php echo e($ui->href('/install',$county)); ?>"><?php echo $__env->make('icons.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><span>نصب اپلیکیشن</span></a>
            <div class="iran-container"><div class="iran-img">
                <button type="button" id="flagSwitcher" aria-label="انتخاب زبان" :aria-expanded="language" @click="language=!language"><?php echo $__env->make('icons.iran', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></button>
                <div class="flag-dropdown" :class="{'active':language}" x-show="language" x-cloak id="flagDropdown"><a class="flag-option" href="/en" lang="en">English</a><a class="flag-option" href="/ar" lang="ar">العربية</a></div>
            </div><a class="search" href="<?php echo e($ui->href('/search',$county)); ?>" aria-label="جستجو در سایت"><?php echo $__env->make('icons.search', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></a></div>
            <div class="sabtnam-container"><div class="sabtnan"><a href="/register">ثبت‌نام شهروندان</a></div><div class="vorod"><a href="<?php echo e(auth()->check() && !auth()->user()->isStaff() ? '/citizen' : '/login'); ?>"><?php echo e(auth()->check() && !auth()->user()->isStaff() ? 'پنل شهروندی' : 'ورود شهروندان'); ?></a></div></div>
        </div>
    </div>
    <div class="imageeee <?php echo e($county ? 'county-portal-banner' : ''); ?>">
        <?php if($county && !$ui->image($organization['banner'] ?? null)): ?>
        <div class="county-banner-template" role="img" aria-label="<?php echo e($portalName); ?>"><svg viewBox="0 0 1380 180" preserveAspectRatio="xMidYMid slice" aria-hidden="true"><defs><pattern id="county-banner-pattern-<?php echo e($county['slug']); ?>" width="350" height="180" patternUnits="userSpaceOnUse"><image href="/design/site/assets/image/amol.png" width="1380" height="180" /></pattern></defs><image href="/design/site/assets/image/amol.png" width="1380" height="180"/><rect x="420" width="540" height="180" fill="url(#county-banner-pattern-<?php echo e($county['slug']); ?>)" /></svg><div class="county-banner-name"><span><?php echo e($county['slug']==='amol' ? 'فرمانداری ویژه شهرستان' : 'فرمانداری شهرستان'); ?></span><strong><?php echo e($county['name']); ?></strong></div></div>
        <?php else: ?>
        <img class="icx-responsive-img" src="<?php echo e($ui->image($county ? ($organization['banner'] ?? null) : ($settings['site.banner'] ?? null)) ?? '/design/site/assets/image/baner.png'); ?>" width="1380" height="180" alt="<?php echo e($portalName); ?>" fetchpriority="high">
        <?php endif; ?>
        <div class="shoar-sal"><img src="<?php echo e($ui->image($settings['site.slogan'] ?? null) ?? '/design/site/assets/image/شعار پ.png'); ?>" alt="شعار سال"></div>
    </div>
    <div class="top-header"><div class="header-box" :data-mega-open="mega ? 'true' : null">
        <button type="button" class="header-hamburger" id="hamburgerBtn" aria-label="باز کردن فهرست سایت" :aria-expanded="mobile" aria-controls="mobileMenu" @click="mobile=true"><span></span><span></span><span></span></button>
        <div class="hum-logo"><a href="<?php echo e($ui->href('/',$county)); ?>"><img src="<?php echo e($logo); ?>" width="150" height="162" alt="<?php echo e($portalName); ?>"></a></div>
        <nav class="desktop-menu" aria-label="منوی اصلی">
            <div class="menu-right">
                <div class="menu-item"><div class="rast"><?php echo $__env->make('icons.home', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><a href="<?php echo e($ui->href('/',$county)); ?>">صفحه اصلی</a></div></div>
                <div class="menu-item has-mega source-mega" :class="{'is-open':mega}" @mouseenter="openMega()" @mouseleave="closeMega()" @focusin="openMega()" @focusout="if(!$el.contains($event.relatedTarget))mega=false">
                    <div class="rast"><?php echo $__env->make('icons.services', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><button type="button" id="khadmat" :aria-expanded="mega" aria-controls="source-services-menu" @click="openMega()" @keydown.arrow-down.prevent="openMega();$nextTick(()=>$refs.firstCategory?.focus())">خدمات <svg class="source-mega-chevron" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="m6 9 6 6 6-6"/></svg></button></div>
                    <div class="mega-menu" id="source-services-menu" role="region" aria-label="خدمات و بخش‌های <?php echo e($portalName); ?>" x-show="mega" x-cloak>
                        <ul class="categories"><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li :class="{'active':category===<?php echo e($i); ?>}" @mouseenter="category=<?php echo e($i); ?>"><button type="button" <?php if($i===0): ?>x-ref="firstCategory"<?php endif; ?> @focus="category=<?php echo e($i); ?>" @click="category=<?php echo e($i); ?>" :aria-expanded="category===<?php echo e($i); ?>" aria-controls="source-submenu-<?php echo e($i); ?>"><span class="category-text"><?php echo e($local($item['href'])==='/services' ? 'خدمات الکترونیکی' : $item['title']); ?></span><?php echo $__env->make('icons.arrow', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></button></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
                        <div class="submenus"><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div class="submenu <?php echo e($i===0 ? 'active' : ''); ?>" :class="{'active':category===<?php echo e($i); ?>}" x-show="category===<?php echo e($i); ?>" id="source-submenu-<?php echo e($i); ?>">
                            <div class="source-mega-heading"><div><span>دسترسی به بخش‌های <?php echo e($county ? 'فرمانداری' : 'استانداری'); ?></span><h2><?php echo e($item['title']); ?></h2></div><a href="<?php echo e($item['href']); ?>">مشاهدهٔ بخش ←</a></div>
                            <?php echo $__env->make('partials.mega-branch',['branch'=>$item], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        </div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div>
                    </div>
                </div>
                <div class="menu-item"><div class="rast"><?php echo $__env->make('icons.poll', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><a href="<?php echo e($ui->href('/polls',$county)); ?>">نظرسنجی</a></div></div>
            </div>
            <div class="logo-wrapper"><a href="<?php echo e($ui->href('/',$county)); ?>" aria-label="صفحه اصلی <?php echo e($portalName); ?>"><img src="<?php echo e($logo); ?>" width="150" height="162" alt="<?php echo e($portalName); ?>"></a></div>
            <div class="menu-left">
                <?php $__currentLoopData = ['/about'=>'about','/managers'=>'people']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $href=>$icon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php ($item=$rootLink($href)); ?>
                    <?php if($item): ?><div class="menu-item source-direct-menu" x-data="{open:false,timer:null}" :class="{'is-open':open}" @mouseenter="clearTimeout(timer);open=true;mega=false" @mouseleave="timer=setTimeout(()=>open=false,240)" @focusin="open=true;mega=false" @focusout="if(!$el.contains($event.relatedTarget))open=false" @click.outside="open=false" @keydown.escape.prevent.stop="open=false">
                        <div class="rast"><?php echo $__env->make('icons.'.$icon, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><a href="<?php echo e($item['href']); ?>"><?php echo e($item['title']); ?></a><button class="source-direct-toggle" type="button" aria-label="زیرمنوی <?php echo e($item['title']); ?>" :aria-expanded="open" @click="open=true">⌄</button></div>
                        <?php if(!empty($item['children'])): ?><div class="source-direct-panel" x-show="open" x-cloak><div class="source-mega-heading"><div><span>بخش‌های پرتال</span><h2><?php echo e($item['title']); ?></h2></div><a href="<?php echo e($item['href']); ?>">مشاهدهٔ همه ←</a></div><div class="source-direct-grid"><?php $__currentLoopData = $item['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div><a class="source-direct-title" href="<?php echo e($child['href']); ?>"><?php echo e($child['title']); ?> ←</a><?php $__currentLoopData = $child['children'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><a class="source-direct-child" href="<?php echo e($link['href']); ?>"><?php echo e($link['title']); ?></a><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div></div><?php endif; ?>
                    </div><?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="menu-item"><div class="rast"><?php echo $__env->make('icons.agreement', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><a href="<?php echo e($ui->href('/service-agreement',$county)); ?>">توافق خدمات</a></div></div>
                <div class="menu-item ai-menu-item"><div class="rast"><span class="ai-badge"><?php echo $__env->make('icons.ai', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> AI</span><a href="<?php echo e($ui->href('/assistant',$county)); ?>">هوش مصنوعی سازمانی</a></div></div>
            </div>
        </nav>
        <div class="mm-backdrop" id="mmBackdrop" :class="{'active':mobile}" x-show="mobile" x-cloak @click="dismiss()"></div>
        <div class="mobile-menu-overlay active" id="mobileMenu" role="dialog" aria-modal="true" aria-label="فهرست سایت" x-ref="drawer" x-show="mobile" x-cloak @keydown.tab="trap($event)">
            <div class="mm-header"><img src="<?php echo e($logo); ?>" class="mm-logo" alt="<?php echo e($portalName); ?>"><button type="button" x-ref="closeMenu" id="closeMobileMenu" class="mm-close" aria-label="بستن منو" @click="dismiss()">×</button></div>
            <?php echo $__env->make('partials.mobile-menu',['entries'=>$navigation], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <div class="mm-utility"><?php $__currentLoopData = $utility; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$label,$href]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><a href="<?php echo e($ui->href($href,$county)); ?>"><?php echo e($label); ?></a><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div><div class="mm-footer"><a href="<?php echo e($ui->href('/install',$county)); ?>">نصب اپلیکیشن</a><a href="/sitemap">نقشه سایت</a></div>
        </div>
    </div><div class="header-paen"><div class="marquee"><div class="marquee-content"><span><?php echo e($settings['site.slogan_text'] ?? 'اقتصاد مقاومتی در سایه وحدت ملی و امنیت ملی'); ?></span></div></div></div></div>
</header>
<?php /**PATH /Users/amirriahi/Sadra Computer/ostandari-laravel/resources/views/partials/header.blade.php ENDPATH**/ ?>