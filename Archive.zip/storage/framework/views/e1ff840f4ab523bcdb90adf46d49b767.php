<!doctype html>
<html lang="<?php echo e($page['lang'] ?? 'fa'); ?>" dir="<?php echo e(($page['lang'] ?? 'fa') === 'en' ? 'ltr' : 'rtl'); ?>" data-citizen-demo="<?php echo e(config('website.citizen_demo') ? 'true' : 'false'); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e($title ?? 'پرتال استانداری مازندران'); ?></title>
    <meta name="description" content="<?php echo e($description ?? 'درگاه الکترونیکی استانداری مازندران و خدمات مردمی'); ?>">
    <link rel="preload" as="font" type="font/woff2" href="/design/site/assets/fonts/Vazirmatn-VariableFont_wght.woff2" crossorigin="anonymous">
    <?php if(isset($page['css'])): ?><link rel="stylesheet" href="<?php echo e($page['css']); ?>"><?php endif; ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css','resources/js/app.ts']); ?>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>
<?php echo $__env->yieldContent('body'); ?>
<?php if(isset($page)): ?><script id="portal-page" type="application/json"><?php echo \Illuminate\Support\Js::encode($page); ?></script><?php endif; ?>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH /Users/amirriahi/Sadra Computer/ostandari-laravel/resources/views/layouts/base.blade.php ENDPATH**/ ?>