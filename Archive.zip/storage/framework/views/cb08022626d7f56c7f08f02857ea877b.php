<?php $__env->startPush('styles'); ?><link rel="stylesheet" href="/styles/home-page.css"><?php $__env->stopPush(); ?>
<?php $__env->startSection('body'); ?>
<div x-data="portalPage" data-design="<?php echo e($page['scope']); ?>" data-preview="false" data-section="site" data-path="<?php echo e(request()->getPathInfo()); ?>" class="min-h-screen w-full font-vazirmatn">
    <div class="container-asli source-portal" data-county-portal="<?php echo e($county['slug'] ?? ''); ?>">
        <?php echo $__env->make('partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <main id="main-content" class="source-main <?php echo e($view==='home' ? 'source-home' : 'source-content'); ?>">
            <?php if($view!=='home'): ?><nav class="source-breadcrumb" aria-label="مسیر صفحه"><a href="<?php echo e($ui->href('/',$county)); ?>">صفحه اصلی</a><span aria-hidden="true">/</span><h1><?php echo e($title); ?></h1></nav><?php endif; ?>
            <?php echo $__env->make('site.'.$view, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </main>
    </div>
    <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/amirriahi/Sadra Computer/ostandari-laravel/resources/views/site/page.blade.php ENDPATH**/ ?>